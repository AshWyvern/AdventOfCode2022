﻿/* Advent of Code 2022 - December 3rd
https://adventofcode.com/2022/day/3
Text file with puzzle inputs found at:
"Desktop\C# Projects\Advent of Code\Puzzle Inputs\Dec3rd.txt"

Character priorities:
a through z - 1 through 26.
A through Z - 27 through 52.
*/

using System.Runtime.InteropServices;
using System.Text;

namespace DayThree
{
    internal class Program
    {
        #region Part One
        static void PartOne()
        {
            int priority_sum = 0;

            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\C# Projects\Advent of Code\Puzzle Inputs\Dec3rd.txt")) // Change if necessary.
            {
                // Initialises three lists:
                // line_chars - contains all characters from a line.
                // compartment1 - contains all items (chars) in compartment 1 (first half of string).
                // compartment2 - contains all items (chars) in compartment 2 (second half of string).
                List<char> line_chars = new List<char>();
                List<char> compartment1 = new List<char>();
                List<char> compartment2 = new List<char>();

                // Adds each character of the line to a list.
                for (int i = 0; i < line.Length; i++)
                {
                    line_chars.Add(line[i]); // Adds each character in the line to the line_chars list.
                }
                // Adds the first half (the first compartment) of the list to another list.
                for (int i = 0; i < line_chars.Count / 2; i++)
                {
                    compartment1.Add(line_chars[i]);
                }
                // Adds the second half (the second compartment) of the list to another list.
                for (int i = line_chars.Count / 2; i < line_chars.Count; i++)
                {
                    compartment2.Add(line_chars[i]);
                }

                // Intialises a list to contain items that appear in both compartments.
                List<char> duplicate_items = new List<char>();

                // Checks each item of both compartments, adds duplicates to list.
                foreach (char item1 in compartment1)
                {
                    foreach (char item2 in compartment2)
                    {
                        if (item1 == item2) // Duplicate item in both compartments.
                        {
                            duplicate_items.Add(item1);
                        }
                    }
                }

                byte[] item_ascii = new byte[1]; // Creates a new single-element array to contain the ASCII value of the duplicate character. 
                item_ascii = Encoding.ASCII.GetBytes(duplicate_items.ToArray()); // Converts the characters into decimal ASCII values.
                if (char.IsUpper(duplicate_items[0]) == true) // If the duplicate is upper-case (ASCII val 65 - 90).
                {
                    item_ascii[0] -= 38; // See above for priority ranges.
                }
                else // If the duplicate is lower-case (ASCII val 97 - 122).
                {
                    item_ascii[0] -= 96; // See above for priority ranges.
                }
                priority_sum += item_ascii[0];
            }

            Console.Write($"Part One\nThe sum of the priorities is: {priority_sum}");
        }
        #endregion

        #region Part Two - WIP
        static void PartTwo()
        {
            /* string split example:
            string[] words = elf_chars[0].Split(",");
            */
            int priority_sum = 0;

            List<string> all_items = new List<string>();
            string group_items = "";

            int counter = 0;
            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\C# Projects\Advent of Code\Puzzle Inputs\Dec3rd.txt")) // Change if necessary.
            {
                counter++;
                if (counter != 3)
                {
                    group_items = group_items + line + ",";
                }
                else
                {
                    counter = 0;
                    group_items = group_items + line;
                    all_items.Add(group_items);
                    Console.Write($"\n\n\nGroup string: {group_items}");
                    group_items = "";
                }
            }

            Console.Write($"\nPart Two\nThe sum of the priorities is: {priority_sum}");
        }

        #region Duplicates Check
        static int DuplicateCheck(List<string> all_items)
        {
            // do this lol
        }
        #endregion
        #endregion

        #region Main
        static void Main(string[] args)
        {
            PartOne();
            PartTwo();
        }
        #endregion
    }
}