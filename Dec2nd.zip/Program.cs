﻿/* Advent of Code 2022 - December 2nd
https://adventofcode.com/2022/day/2
Puzzle input found at:
C:\Users\jason\Desktop\Programming\C# Projects\Advent of Code\2022\Puzzle Inputs - (Desktop PC)

Shape points:
1 - Rock (A or X (part 1))
2 - Paper (B or Y (part 1)) 
3 - Scissors (C or Z (part 1))

Win/Loss points:
0 - Loss
3 - Draw
6 - Win

Win condition letters - part 2:
X - Loss
Y - Draw
Z - Win
*/

namespace DayTwo
{
    internal class Program
    {
        #region Part One
        static void PartOne()
        {
            int total_score = 0;

            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\Programming\C# Projects\Advent of Code\2022\Puzzle Inputs\Dec2nd.txt")) // Change if necessary.
            {
                char opponent_choice = line[0]; // Takes the first character of the line, the opponent's choice.
                char player_choice = line[2]; // Takes the third character of the line (including the space), the player's choice.

                total_score += ShapePoints(player_choice) + WinCondPoints(opponent_choice, player_choice); // Combines the points of the player's shape and whether or not they won/lost.
            }

            Console.Write($"Part One\nYour total score is: {total_score}\n");
        }

        #region Chosen Shape Points
        // This function returns the points of the player's shape.
        static int ShapePoints(char player_choice)
        {
            if (player_choice == 'X') // Rock, 1 point returned.
            {
                return 1;
            }
            else if (player_choice == 'Y') // Paper, 2 points returned.
            {
                return 2;
            }
            else // Scissors, 3 points returned.
            {
                return 3;
            }
        }
        #endregion

        #region Win Condition Points
        // This function returns the points for a win/loss/draw.
        static int WinCondPoints(char opponent_choice, char player_choice)
        {
            switch (opponent_choice)
            {
                case 'A': // Opponent chose rock.
                    if (player_choice == 'Y') // Player chose paper (player win), 6 points returned.
                    {
                        return 6;
                    }
                    else if (player_choice == 'X') // Player chose rock (draw), 3 points returned.
                    {
                        return 3;
                    }
                    else // Player chose scissors (player loss), no points returned.
                    {
                        return 0;
                    }
                    break;
                case 'B': // Opponent chose paper.
                    if (player_choice == 'Z') // Player chose scissors (player win), 6 points returned.
                    {
                        return 6;
                    }
                    else if (player_choice == 'Y') // Player chose paper (draw), 3 points returned.
                    {
                        return 3;
                    }
                    else // Player chose rock (player loss), no points returned.
                    {
                        return 0;
                    }
                    break;
                case 'C': // Opponent chose scissors.
                    if (player_choice == 'X') // Player chose rock (player win), 6 points returned.
                    {
                        return 6;
                    }
                    else if (player_choice == 'Z') // Player chose scissors (draw), 3 points returned.
                    {
                        return 3;
                    }
                    else // Player chose paper (player loss), no points returned.
                    {
                        return 0;
                    }
                    break;
                default: // Will not occur; although means *all* paths return a value.
                    return 0;
                    break;
            }
        }
        #endregion
        #endregion

        #region Part Two
        static void PartTwo()
        {
            int total_score = 0;

            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\Programming\C# Projects\Advent of Code\2022\Puzzle Inputs\Dec2nd.txt")) // Change if necessary.
            {
                char opponent_choice = line[0]; // Takes the first character of the line, the opponent's choice.
                char win_condition = line[2]; // Takes the third character of the line (including the space), the win condition.

                total_score += PointsEarned(opponent_choice, win_condition);
            }

            Console.Write($"Part Two\nYour total score is: {total_score}");
        }

        #region Point Calculation
        static int PointsEarned(char opponent_choice, char win_condition)
        {
            switch (opponent_choice)
            {
                case 'A': // Opponent chose rock.
                    if (win_condition == 'X') // Player must lose.
                    {
                        int awarded_points = 3; // 3 points for scissors + 0 for loss.
                        return awarded_points;
                    }
                    else if (win_condition == 'Z') // Player must win.
                    {
                        int awarded_points = 2 + 6; // 2 points for paper + 6 for win.
                        return awarded_points;
                    }
                    else // Player must draw.
                    {
                        int awarded_points = 1 + 3; // 1 points for rock + 3 for draw.
                        return awarded_points;
                    }
                    break;
                case 'B': // Opponent chose paper.
                    if (win_condition == 'X') // Player must lose.
                    {
                        int awarded_points = 1; // 1 points for rock + 0 for loss.
                        return awarded_points;
                    }
                    else if (win_condition == 'Z') // Player must win.
                    {
                        int awarded_points = 3 + 6; // 3 points for scissors + 6 for win.
                        return awarded_points;
                    }
                    else // Player must draw.
                    {
                        int awarded_points = 2 + 3; // 2 points for paper + 3 for draw.
                        return awarded_points;
                    }
                    break;
                case 'C': // Opponent chose scissors.
                    if (win_condition == 'X') // Player must lose.
                    {
                        int awarded_points = 2; // 2 points for paper + 0 for loss.
                        return awarded_points;
                    }
                    else if (win_condition == 'Z') // Player must win.
                    {
                        int awarded_points = 1 + 6; // 1 points for rock + 6 for win.
                        return awarded_points;
                    }
                    else // Player must draw.
                    {
                        int awarded_points = 3 + 3; // 3 points for scissors + 3 for draw.
                        return awarded_points;
                    }
                    break;
                default: // Will not occur; although means *all* paths return a value.
                    return 0;
                    break;
            }
        }
        #endregion
        #endregion

        #region Main
        static void Main(string[] args)
        {
            PartOne();
            PartTwo();
        }
        #endregion
    }
}