﻿namespace DayOne
{
    internal class Program
    {
        static void Main(string[] args)
        {
            List<int> elf_calories = new List<int>();
            List<int> calorie_totals = new List<int>();

            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\C# Projects\Advent of Code\Puzzle Inputs\DayOne.txt"))
            {
                if (line == "")
                {
                    int total = elf_calories.Sum();
                    calorie_totals.Add(total);
                    elf_calories.Clear();
                }
                else
                {
                    elf_calories.Add(Int32.Parse(line));
                }
            }

            int highest_total = calorie_totals.Max();
            Console.Write($"The highest total is: {highest_total}");
        }
    }
}