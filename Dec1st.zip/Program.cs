﻿/* Advent of Code 2022 - December 1st
https://adventofcode.com/2022/day/1
Text file with puzzle inputs found at:
"Desktop\C# Projects\Advent of Code\Puzzle Inputs\DayOne.txt"
*/

namespace DayOne
{
    internal class Program
    {
        #region Part One
        static void PartOne()
        {
            // Initialises two lists.
            // elf_calories: stores all of the calories of a single elf; cleared when total is calculated.
            // calorie_totals: stores the totals of every elf's calories.
            List<int> elf_calories = new List<int>(); 
            List<int> calorie_totals = new List<int>();

            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\C# Projects\Advent of Code\Puzzle Inputs\DayOne.txt"))
            {
                if (line == "") // If the line is empty, the elf has no more calories and is totaled.
                {
                    int total = elf_calories.Sum(); 
                    calorie_totals.Add(total); // The total is added to the totals list.
                    elf_calories.Clear();
                }
                else // Otherwise, it adds the amount of calories to the temporary list.
                {
                    elf_calories.Add(Int32.Parse(line));
                }
            }

            int highest_total = calorie_totals.Max(); // This method returns the highest integer in the totals list.
            Console.Write($"Part 1\nThe highest total is: {highest_total}\n");
        }
        #endregion

        #region Part Two
        static void PartTwo()
        {
            // Initialises two lists.
            // elf_calories: stores all of the calories of a single elf; cleared when total is calculated.
            // calorie_totals: stores the totals of every elf's calories.
            List<int> elf_calories = new List<int>();
            List<int> calorie_totals = new List<int>();

            foreach (string line in File.ReadLines(@"C:\Users\jason\Desktop\C# Projects\Advent of Code\Puzzle Inputs\DayOne.txt"))
            {
                if (line == "") // If the line is empty, the elf has no more calories and is totaled.
                {
                    int total = elf_calories.Sum();
                    calorie_totals.Add(total); // The total is added to the totals list.
                    elf_calories.Clear();
                }
                else // Otherwise, it adds the amount of calories to the temporary list.
                {
                    elf_calories.Add(Int32.Parse(line));
                }
            }

            List<int> highest_nums = new List<int>(); // A new list is created to contain the three highest totals.

            for (int i = 0; i < 3; i++) // Loops 3 times.
            {
                int highest_total = calorie_totals.Max(); // Returns the highest value.
                highest_nums.Add(highest_total); // Adds the total to the highest totals list.

                int index = calorie_totals.IndexOf(highest_total); // Returns the index at which the highest total was found.
                calorie_totals.RemoveAt(index); // Deletes the highest total found at the index, leaving the second highest now the first highest.
            }

            Console.Write($"Part 2\nThe highests total are : {highest_nums[0]}, {highest_nums[1]} & {highest_nums[2]}\n" +
                $"Their sum is {highest_nums.Sum()}");
        }
        #endregion

        static void Main(string[] args)
        {
            PartOne();
            PartTwo();
        }
    }
}